﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfAppStudPract.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public Frame Bludoframe;
        public Frame users;
        public Frame adminFrame;
        public MainWindow()
        {
            InitializeComponent();
            tabProfil.Visibility = Visibility.Collapsed;

            Bludoframe = bludoFrame;
            users = usersFrame;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        { 
            userName.Text = AuthWindow.currentUser.LastName + " " + AuthWindow.currentUser.FirstName;
            if (AuthWindow.currentUser.RoleId == 1)
            {
                tabProfil.Visibility = Visibility.Visible;
                users.Navigate(new Pages.AdminPage());
            }
            bludoFrame.Navigate(new Pages.BludoPage());
        }

        private void btnPfofile_Click(object sender, RoutedEventArgs e)
        {
            ProfilWindow profilWindow = new ProfilWindow(); 
            profilWindow.ShowDialog();
        }

        private void btnEscape_Click(object sender, RoutedEventArgs e)
        {

            AuthWindow authWindow = new AuthWindow();
            this.Close();
            authWindow.Show();


        }

        private void bludoFrame_Navigated(object sender, NavigationEventArgs e)
        {

        }
    }
}