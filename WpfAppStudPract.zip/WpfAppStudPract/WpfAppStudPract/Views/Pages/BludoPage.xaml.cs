﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfAppStudPract.DbServise;
using WpfAppStudPract.Model;

namespace WpfAppStudPract.Views.Pages
{
    /// <summary>
    /// Логика взаимодействия для BludoPage.xaml
    /// </summary>
    public partial class BludoPage : Page
    {
        BludaFromDB bludaFromDB = new BludaFromDB();
        ObservableCollection<Bludo> listBludo = new ObservableCollection<Bludo>();
        public BludoPage()
        {
            InitializeComponent();
        }

        private void AllBludos()
        {
            listBludo = bludaFromDB.LoadBludos();
            ListVievBludas.ItemsSource = listBludo;
        }



        private void TbPoisk_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ListVievBludas_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            AllBludos();
        }
    }
}
