﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppStudPract.DbServise;
using WpfAppTam.DbService;

namespace WpfAppStudPract.Views
{
    /// <summary>
    /// Логика взаимодействия для RegistrationForm.xaml
    /// </summary>
    public partial class RegistrationForm : Window
    {
        UserFromDb userFromDb = new UserFromDb();

        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            if (tbFirstName.Text == "" ||  tbLastName.Text == "" || string.IsNullOrWhiteSpace(tbPassword.Password) || string.IsNullOrWhiteSpace(tbPasswordRepeat.Password))
            {
                MessageBox.Show("Необходимо заполнить все поля!"); return;
            }

            bool rez = userFromDb.CheckPassword(tbPassword.Password, tbPasswordRepeat.Password);

            if (!rez)
            {
                return;
            }
            else
            if (userFromDb.CheckUser(tbLogin.Text))
            {
                userFromDb.UserAdd(tbLogin.Text, tbPassword.Password, tbFirstName.Text, tbLastName.Text, (DateTime)dpBirthDate.SelectedDate);
            }
            else return;
        }
    }
}
