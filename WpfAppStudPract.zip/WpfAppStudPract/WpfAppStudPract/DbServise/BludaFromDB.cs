﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Npgsql;
using WpfAppStudPract.Model;
using WpfAppTam.DbService;

namespace WpfAppStudPract.DbServise
{
    internal class BludaFromDB
    {
        public ObservableCollection<Bludo> LoadBludos() 
        {

            ObservableCollection<Bludo> bludos = new ObservableCollection<Bludo>();
            NpgsqlConnection connection = new NpgsqlConnection(Connect.connectionStr);

            try
            {
                connection.Open();
                string sqlQuery = "SELECT bludo_id, bludo_name, category_name, osnova, vihod, bludo_image " + "FROM public.bluda join public.category_bluda on id_categirya = category_id";
            
                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, connection);
                NpgsqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    bludos.Add(new Bludo((int)reader[0], reader[1].ToString(), reader[2].ToString(), reader[3].ToString(), (int)reader[4], reader[5].ToString()));
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            connection.Close();
            return bludos;

        }

    }
}
