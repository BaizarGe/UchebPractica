﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppStudPract.DbServise;

namespace WpfAppStudPract.Views
{
    /// <summary>
    /// Логика взаимодействия для ProductAddForm.xaml
    /// </summary>
    public partial class ProductAddForm : Window
    {
        ProductsFrmBd productsFrmBd = new ProductsFrmBd();

        public ProductAddForm()
        {
            InitializeComponent();
        }

        private void btnAuth_Click(object sender, RoutedEventArgs e)
        {
            if (tbProductName.Text == "" && tbBelky.Text == "" && tbJiry.Text == "" || tbUglevody.Text == "") {

                MessageBox.Show("Должны быть заполнены все поля!!!");
                
            } else
            {

                productsFrmBd.AddProduct(tbProductName.Text, Convert.ToInt32(tbBelky.Text), Convert.ToInt32(tbJiry.Text), Convert.ToInt32(tbUglevody.Text));

            }
        }

    }
}
