﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppStudPract.DbServise;
using WpfAppStudPract.Model;

namespace WpfAppStudPract.Views
{
    /// <summary>
    /// Логика взаимодействия для ProfilWindow.xaml
    /// </summary>
    /// 

    public partial class ProfilWindow : Window
    {
        bool isPasswordChanged;
        bool PasswordVisible;
        UserFromDb userFromDb = new UserFromDb();
        public ProfilWindow()
        {
            InitializeComponent();
        }

        private void btnShowChangePassword_Click(object sender, RoutedEventArgs e)
        {
            spPasswordBlock.Visibility = Visibility.Visible;
            btnShowChangePassword.Visibility = Visibility.Collapsed;

            isPasswordChanged = true;
            PasswordVisible = true;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (tbFirstName.Text =="" || tbLastName.Text == "")
            {
                MessageBox.Show("Заполните Имя и Фамилию");
                return;
            }

            bool isPasswordChanged = (spPasswordBlock.Visibility == Visibility.Visible);

            if (isPasswordChanged)
            {

                if (pbOldPassword.Password == "" || pbNewPassword.Password == "" || pbConfirmPassword.Password == "")
                {
                    MessageBox.Show("Имеются пустые поля с паролями!");
                    return;
                }

                if (!Verification.VerifySHA512Hash(pbOldPassword.Password, AuthWindow.currentUser.Password))
                {
                    MessageBox.Show("Некоректно введен старый пароль!");
                    return;
                }

                User userUpd = new User(AuthWindow.currentUser.UserId, tbFirstName.Text, tbLastName.Text, tbPatronymic.Text, AuthWindow.currentUser.DateOfBirthday, AuthWindow.currentUser.Login, pbNewPassword.Password, tbAddress.Text, AuthWindow.currentUser.RoleId, tbPhone.Text);

                userFromDb.UserUpdateProfil(userUpd, true);


                spPasswordBlock.Visibility = Visibility.Hidden;
                btnShowChangePassword.Visibility = Visibility.Visible;

            } else
            {
                User userUpd = new User(AuthWindow.currentUser.UserId, tbFirstName.Text, tbLastName.Text, tbPatronymic.Text, AuthWindow.currentUser.DateOfBirthday, AuthWindow.currentUser.Login, AuthWindow.currentUser.Password, tbAddress.Text, AuthWindow.currentUser.RoleId, tbPhone.Text);

                userFromDb.UserUpdateProfil(userUpd, false);
            }

        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (AuthWindow.currentUser != null)
            {
                User user = AuthWindow.currentUser;

                tbFirstName.Text = AuthWindow.currentUser.FirstName;
                tbLastName.Text = AuthWindow.currentUser.LastName;
                tbPatronymic.Text = AuthWindow.currentUser.Patronymic;
                dpBirthDate.SelectedDate = AuthWindow.currentUser.DateOfBirthday;
                tbPhone.Text = AuthWindow.currentUser.Phone;
                tbAddress.Text = AuthWindow.currentUser.Adress;

            } else
            {
                MessageBox.Show("Данные не найдены!");
            }
        }

        private void tbFirstName_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
