﻿using System;
using System.IO;

namespace WpfAppStudPract.Domain
{
    internal class ImageWorker
    {
        public string ImagePath(string imageName)
        {
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            string imagesDir = Path.Combine(baseDir, "..", "..", "..", "Images");

            string defaultImagePath = Path.Combine(imagesDir, "picture.jpg");

            if (!String.IsNullOrEmpty(imageName) && !String.IsNullOrWhiteSpace(imageName))
            {
                string realImagePath = Path.Combine(imagesDir, imageName);
                if (File.Exists(realImagePath))
                {
                    return realImagePath;
                }
            }

            return defaultImagePath;
        }
    }
}