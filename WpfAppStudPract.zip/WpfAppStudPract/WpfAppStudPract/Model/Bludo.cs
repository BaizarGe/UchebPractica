﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfAppStudPract.Domain;

namespace WpfAppStudPract.Model
{
    internal class Bludo
    {
        public int Id { get; set; }
        public string BludoName { get; set; }
        public string Categoriya { get; set; }
        public string Osnova { get; set; }
        public int Vyhod { get; set; }
        string image;
        public string ImageWithPath
        {
            get
            {
                string imagePath = new ImageWorker().ImagePath(image);

                return imagePath;
            }
            set
            {
                image = value;
            }
        }

        public Bludo()
        {

        }

        public Bludo(int id, string bludoName, string categoriya, string osnova, int vyhod, string image)
        {
            Id = id;    
            BludoName = bludoName;
            Categoriya = categoriya;
            Osnova = osnova;
            Vyhod = vyhod;
            this.image = image;
        }
    }
}
