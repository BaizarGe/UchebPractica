﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfAppStudPract.DbServise;
using WpfAppStudPract.Model;

namespace WpfAppStudPract.Views.Pages
{
    /// <summary>
    /// Логика взаимодействия для ProductPage.xaml
    /// </summary>
    public partial class ProductPage : Page
    {
        ProductsFrmBd productsFrmBd = new ProductsFrmBd();

        public ProductPage()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            
            dgProductsGrid.ItemsSource = productsFrmBd.LoadProduct();

        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {

            ProductAddForm productAddForm = new ProductAddForm();
            productAddForm.ShowDialog();
            Refresh();

        }

        private void Refresh()
        {
            dgProductsGrid.ItemsSource = productsFrmBd.LoadProduct();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (dgProductsGrid.SelectedItem is Product selectedProduct)
            {
                productsFrmBd.DeleteProduct(selectedProduct.Id);
                Refresh();
            }
            else
            {
                MessageBox.Show("Выберите продукт в таблице.");
            }
        }
    }
}
