﻿using MaterialDesignThemes.Wpf;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpfAppStudPract.Model;
using WpfAppStudPract.Views;
using WpfAppTam.DbService;

namespace WpfAppStudPract.DbServise
{
    internal class UserFromDb
    {
        public User GetUser(string login, string password)
        {
            User user = null;
            try
            {
                NpgsqlConnection connect = new NpgsqlConnection(Connect.connectionStr);
                connect.Open();

                string sqlQuery = "SELECT user_id, first_name, last_name, patronymic, date_of_birthday, login, password, adress, role_id, phone " + "FROM users WHERE login=@login";
                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, connect);
                cmd.Parameters.AddWithValue("login", login);

                NpgsqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    DateTime dateOfBirth = reader.GetFieldValue<DateTime>(4);

                    if (password != "")
                    {
                        if (Verification.VerifySHA512Hash(password, (string)reader["password"]))
                        {
                            user = new User((int)reader[0], reader[1].ToString(), reader[2].ToString(), reader[3].ToString(), dateOfBirth, reader[5].ToString(), reader[6].ToString(), reader[7].ToString(), (int)reader[8], reader[9].ToString());

                        }
                        else
                        {
                            MessageBox.Show("Неверный пароль");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Нет такого пользователя");
                }
                return user;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message); return user;
            }
        }

        public List<User> GetUserList()
        {
            List<User> users = new List<User>();
            try
            {
                NpgsqlConnection connect = new NpgsqlConnection(Connect.connectionStr);
                connect.Open();

                string sqlQuery = "SELECT user_id, first_name, last_name, patronymic, date_of_birthday, login, password, adress, role_id, phone " + "FROM users";
                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, connect);

                NpgsqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    DateTime dateOfBirth = reader.GetFieldValue<DateTime>(4);

                    users.Add(new User((int)reader[0], reader[1].ToString(), reader[2].ToString(), reader[3].ToString(), dateOfBirth, reader[5].ToString(), reader[6].ToString(), reader[7].ToString(), (int)reader[8], reader[9].ToString()));

                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return users;
        }

        public bool CheckPassword(string password, string passRepeat)
        {
            if (password.Length < 6)
            {
                MessageBox.Show("Длина пароля не может быть меньше 6 символов");
                return false;
            }
            else
            {
                bool f = false;
                bool f1 = false;
                bool f2 = false;

                for (int i = 0; i < password.Length; i++)
                {
                    if (Char.IsDigit(password[i])) f1 = true;
                    if (Char.IsUpper(password[i])) f2 = true;
                    if (f1 && f2) break;
                }

                if (!(f1 && f2))
                {
                    MessageBox.Show("Пароль должен содержать хотя бы одну цифру и одну заглавную букву!");
                    return false;
                }


                string simbol = "!@#$*";
                for (int i = 0; i < password.Length; i++)
                {
                    if (simbol.Contains(password[i].ToString()))
                    {
                        f = true;
                        break;
                    }
                }

                if (!f)
                {
                    MessageBox.Show("Пароль должен содержать один из символов !@#$*");
                    return false;
                }


                if (password != passRepeat)
                {
                    MessageBox.Show("Неверно подтвержден пароль");
                    return false;
                }

                return true;
            }
        }

        public bool CheckUser(string login)
        {
            try
            {
                NpgsqlConnection connect = new NpgsqlConnection(Connect.connectionStr);
                connect.Open();
                string sqlExp = "SELECT login from Users where login=@login";
                NpgsqlCommand cmd = new NpgsqlCommand(sqlExp, connect);
                cmd.Parameters.AddWithValue("@login", login);
                NpgsqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    MessageBox.Show("Такой логин уже есть"); return false;
                }
                else
                {
                    reader.Close();
                    return true;
                }
            }
            catch (NpgsqlException ex)
            { MessageBox.Show(ex.Message); return false; }
        }

        public void UserAdd(string login, string password, string fisrtName, string lastName, DateTime bithday)
        {

            NpgsqlConnection connection = new NpgsqlConnection(Connect.connectionStr);
            try
            {
                connection.Open();
                string sqlQuery = "INSERT INTO public.users(first_name, last_name, login, password, date_of_birthday)"
                    + $"VALUES (@first_name, @last_name, @login, @password, @date_of_birthday)";

                NpgsqlCommand command = new NpgsqlCommand(sqlQuery, connection);
                command.Parameters.AddWithValue("first_name", fisrtName);
                command.Parameters.AddWithValue("last_name", lastName);
                command.Parameters.AddWithValue("login", login);
                command.Parameters.AddWithValue("date_of_birthday", bithday);

                string hashpassword = Verification.GetSHA512Hash(password);

                command.Parameters.AddWithValue("password", hashpassword);

                int i = command.ExecuteNonQuery();

                if (i == 1)
                {
                    MessageBox.Show("Даные добавлены");
                }

            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
            }

            connection.Close();

        }

        public void UserUpdateProfil(User user, bool isPasswordChanged)
        {

            if (isPasswordChanged == false)
            {
                NpgsqlConnection connection = new NpgsqlConnection(Connect.connectionStr);
                try
                {
                    connection.Open();

                    string sqlQuery = "UPDATE public.users SET first_name = @first_name, last_name = @last_name, patronymic = @patronymic, adress = @adress, phone = @phone " +
                                      "WHERE user_id=@userid";

                    NpgsqlCommand command = new NpgsqlCommand(sqlQuery, connection);

                    command.Parameters.AddWithValue("@first_name", user.FirstName);
                    command.Parameters.AddWithValue("@last_name", user.LastName);
                    command.Parameters.AddWithValue("@patronymic", user.Patronymic);
                    command.Parameters.AddWithValue("@adress", user.Adress);
                    command.Parameters.AddWithValue("@phone", user.Phone);
                    command.Parameters.AddWithValue("@userid", user.UserId);

                    AuthWindow.currentUser.FirstName = user.FirstName;
                    AuthWindow.currentUser.LastName = user.LastName;
                    AuthWindow.currentUser.Patronymic = user.Patronymic;
                    AuthWindow.currentUser.Adress = user.Adress;
                    AuthWindow.currentUser.Phone = user.Phone;


                    int i = command.ExecuteNonQuery();

                    if (i == 1)
                    {
                        MessageBox.Show("Данные обновлены");
                    }
                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                NpgsqlConnection connection = new NpgsqlConnection(Connect.connectionStr);
                try
                {
                    connection.Open();

                    string sqlQuery = "UPDATE public.users SET first_name=@first_name, last_name=@last_name, patronymic=@patronymic, password=@password, adress=@adress,  phone=@phone " +
                                      "WHERE user_id=@userid";

                    NpgsqlCommand command = new NpgsqlCommand(sqlQuery, connection);

                    command.Parameters.AddWithValue("@first_name", user.FirstName);
                    command.Parameters.AddWithValue("@last_name", user.LastName);
                    command.Parameters.AddWithValue("@patronymic", user.Patronymic);
                    command.Parameters.AddWithValue("@adress", user.Adress);
                    command.Parameters.AddWithValue("@phone", user.Phone);
                    command.Parameters.AddWithValue("@userid", user.UserId);

                    string hashpassword = Verification.GetSHA512Hash(user.Password);
                    command.Parameters.AddWithValue("password", hashpassword);


                    AuthWindow.currentUser.FirstName = user.FirstName;
                    AuthWindow.currentUser.LastName = user.LastName;
                    AuthWindow.currentUser.Patronymic = user.Patronymic;
                    AuthWindow.currentUser.Adress = user.Adress;
                    AuthWindow.currentUser.Phone = user.Phone;

                    int i = command.ExecuteNonQuery();

                    if (i == 1)
                    {
                        MessageBox.Show("Данные обновлены");
                    }

                }
                catch (NpgsqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        public void UserDelete(int userid)
        {
            NpgsqlConnection connection = new NpgsqlConnection(Connect.connectionStr);
            try
            {
                connection.Open();

                string sqlQuery = "DELETE FROM public.users " + "WHERE user_id = @userid";

                NpgsqlCommand command = new NpgsqlCommand(sqlQuery, connection);

                command.Parameters.AddWithValue("@userid", userid);

                int i = command.ExecuteNonQuery();

                if (i == 1)
                {
                    MessageBox.Show("Данные удалены");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void UserChangeRole(int userid ,int roleid)
        {
            NpgsqlConnection connection = new NpgsqlConnection(Connect.connectionStr);

            try
            {
                connection.Open();

                string sqlQuery = "UPDATE public.users SET role_id = @roleid " +
                                  "WHERE user_id = @userid";

                NpgsqlCommand command = new NpgsqlCommand(sqlQuery, connection);

                command.Parameters.AddWithValue("@role_id", roleid);
                command.Parameters.AddWithValue("@user_id", userid);

                int i = command.ExecuteNonQuery();

                if (i == 1)
                {
                    MessageBox.Show("Роль изменена!");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
