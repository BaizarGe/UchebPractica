﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppStudPract.DbServise;

namespace WpfAppStudPract.Views
{
    /// <summary>
    /// Логика взаимодействия для PasswordAccess.xaml
    /// </summary>
    public partial class PasswordAccess : Window
    {
        UserFromDb userFromDb = new UserFromDb();
        private int _userid;
        private string _password;

        public PasswordAccess(int userid, string NewPasswd)
        {
            InitializeComponent();

            _userid = userid;
            _password = NewPasswd;  

        }

        private void btnChangePasswordOk_Click(object sender, RoutedEventArgs e)
        {

            userFromDb.UserUpdatePasswd(_userid, _password);
            this.Close();
        }

        private void btnChangePasswordDeny_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
