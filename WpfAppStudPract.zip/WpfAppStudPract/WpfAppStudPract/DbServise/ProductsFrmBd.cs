﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpfAppStudPract.Model;
using WpfAppTam.DbService;

namespace WpfAppStudPract.DbServise
{
    internal class ProductsFrmBd
    {

        public List<Product> LoadProduct()
        {

            List<Product> products = new List<Product>();
            NpgsqlConnection connection = new NpgsqlConnection(Connect.connectionStr);

            try
            {
                connection.Open();
                string sqlQuery = "SELECT product_id, product_name, belky, jiry, uglevody " + "FROM public.products";

                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, connection);
                NpgsqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    products.Add(new Product((int)reader[0], reader[1].ToString(), (int)reader[2], (int)reader[3], (int)reader[4]));
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            connection.Close();
            return products;

        }

        public void AddProduct(string productName, int belky, int jiry, int uglevody)
        {
            NpgsqlConnection connection = new NpgsqlConnection(Connect.connectionStr);
            try
            {
                connection.Open();
                string sqlQuery = "INSERT INTO public.products(product_name, belky, jiry, uglevody)"
                    + $"VALUES (@product_name, @belky, @jiry, @uglevody)";

                NpgsqlCommand command = new NpgsqlCommand(sqlQuery, connection);
                command.Parameters.AddWithValue("product_name", productName);
                command.Parameters.AddWithValue("belky", belky);
                command.Parameters.AddWithValue("jiry", jiry);
                command.Parameters.AddWithValue("uglevody", uglevody);



                int i = command.ExecuteNonQuery();

                if (i == 1)
                {
                    MessageBox.Show("Даные добавлены");
                }

            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
            }

            connection.Close();

        }

        public void DeleteProduct(int productid)
        {
            NpgsqlConnection connection = new NpgsqlConnection(Connect.connectionStr);
            try
            {
                connection.Open();

                string sqlQuery = "DELETE FROM public.products " + "WHERE product_id = @productid";

                NpgsqlCommand command = new NpgsqlCommand(sqlQuery, connection);

                command.Parameters.AddWithValue("@productid", productid);

                int i = command.ExecuteNonQuery();

                if (i == 1)
                {
                    MessageBox.Show("Данные удалены");
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
