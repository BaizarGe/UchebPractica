﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WpfAppTam.DbService
{
    internal class Connect
    {
        internal static string connectionStr = @"Server=172.20.105.123; Port=5432 ; DataBase=Culinary_Tamelkin; User Id=9po12k-24-26 ; Password=Ut4ahhee";
    }
}
