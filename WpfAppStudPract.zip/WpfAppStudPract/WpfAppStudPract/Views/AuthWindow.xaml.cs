﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppStudPract.DbServise;
using WpfAppStudPract.Model;

namespace WpfAppStudPract.Views
{
    /// <summary>
    /// Логика взаимодействия для AuthWindow.xaml
    /// </summary>
    public partial class AuthWindow : Window
    {
        UserFromDb userFromDb = new UserFromDb();
        public static User currentUser { get; set; } = null;

        public AuthWindow()
        {
            InitializeComponent();
        }

        private void btnAuth_Click(object sender, RoutedEventArgs e)
        {
            if (!(login.Text != "" && password.Password != ""))
            {
                MessageBox.Show("Введите данные");
                return;
            }
            else
            {
                currentUser = userFromDb.GetUser(login.Text, password.Password);
                if (currentUser != null)
                {
                    MainWindow mainWindow = new MainWindow();
                    mainWindow.Show();
                    this.Close();
                }
            }
        }

        private void btnRegistration_Click(object sender, RoutedEventArgs e)
        {
            RegistrationForm registrationForm = new RegistrationForm(); 
            registrationForm.ShowDialog();
        }
    }
}
