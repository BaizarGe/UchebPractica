﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppStudPract.Model
{
    internal class Product
    {
        public int Id { get; set; }
        public string ProductName { get; set; }
        public int Belky { get; set; }
        public int Jiry { get; set; }
        public int Uglevody { get; set; }


        public Product(int id, string productName, int belky, int jiry, int uglevody)
        {
            Id = id;
            ProductName = productName;  
            Belky = belky;
            Jiry = jiry;
            Uglevody = uglevody;
        }
    }
}
