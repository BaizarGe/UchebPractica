﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppStudPract.DbServise;
using WpfAppStudPract.Model;

namespace WpfAppStudPract.Views
{
    /// <summary>
    /// Логика взаимодействия для ChangePasswordForm.xaml
    /// </summary>
    public partial class ChangePasswordForm : Window
    {
        UserFromDb userFrom = new UserFromDb();
        private User _user;
        public ChangePasswordForm(User user)
        {

            InitializeComponent();
            tbFirstName.Text = user.FirstName;
            tbLastName.Text = user.LastName;
            _user = user;

        }

        private void btnChangePassword_Click(object sender, RoutedEventArgs e)
        {
            if (userFrom.CheckPassword(pbNewPassword.Password, pbConfirmPassword.Password))
            {
                PasswordAccess passwordAccess = new PasswordAccess(_user.UserId, pbNewPassword.Password);
                passwordAccess.ShowDialog();
            } 
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

    }
}
