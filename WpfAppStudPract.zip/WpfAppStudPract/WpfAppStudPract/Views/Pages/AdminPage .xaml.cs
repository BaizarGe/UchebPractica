﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfAppStudPract.DbServise;
using WpfAppStudPract.Model;

namespace WpfAppStudPract.Views.Pages
{
    /// <summary>
    /// Логика взаимодействия для AdminPage.xaml
    /// </summary>
    public partial class AdminPage : Page
    {
        UserFromDb userFromDb = new UserFromDb();
        public AdminPage()
        {
            InitializeComponent();
        }

        private void UsersGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            User user = dgUserGrid.SelectedItem as User;

            if (user == null)
            {

                tbFirstName.Text = "";
                tbLastName.Text = "";
                tbPatronymic.Text = "";
                tbAdress.Text = "";
                tbPhone.Text = "";
                dpBirthDay.SelectedDate = null;
            }
            else
            {
                tbFirstName.Text = user.FirstName;
                tbLastName.Text = user.LastName;
                tbPatronymic.Text = user.Patronymic;
                tbAdress.Text = user.Adress;
                tbPhone.Text = user.Phone;
                dpBirthDay.SelectedDate = user.DateOfBirthday;
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            List<User> users = userFromDb.GetUserList();

            dgUserGrid.ItemsSource = users;

        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            RegistrationForm registrationForm = new RegistrationForm();
            registrationForm.ShowDialog();

            Refresh();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            User user = dgUserGrid.SelectedItem as User;
            userFromDb.UserDelete(user.UserId);

            Refresh();
        }

        private void Refresh()
        {
            dgUserGrid.ItemsSource = userFromDb.GetUserList();
            dgUserGrid.SelectedItem = null;
        }

        private void btnChangeRole_Click(object sender, RoutedEventArgs e)
        {

            User user = dgUserGrid.SelectedItem as User;

            userFromDb.UserChangeRole(user.UserId, cbRoleName.SelectedIndex);

        }

        private void btnChangePassword_Click(object sender, RoutedEventArgs e)
        {
            User user = dgUserGrid.SelectedItem as User;
            if (!(user == null))
            {
                ChangePasswordForm changePasswordForm = new ChangePasswordForm(user);
                changePasswordForm.ShowDialog();
            } else
            {
                MessageBox.Show("Пользователь не выбран!");
            }
        }
    }
}
